package com.example.SpringBootcampConfigServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootcampConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
